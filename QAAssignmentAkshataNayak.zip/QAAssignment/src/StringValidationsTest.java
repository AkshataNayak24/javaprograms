import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StringValidationsTest {

	@Test
	public void testValidWordForPalindrome() {
		assertTrue(StringValidation.checkPalindrome("level"));
	}
	
	
	@Test
	public void testValidInvalidWordForPalindrome() {
		assertFalse(StringValidation.checkPalindrome("valid"));
	}
	
	@Test
	public void testPositiveWordsForAnagram() {
		assertTrue(StringValidation.checkAnagram("silent", "listen"));
	}
	
	
	@Test
	public void testNegativeWordsForAnagram() {
		assertFalse(StringValidation.checkAnagram("stolen", "listen"));
	}

	@Test
	public void testDifferentLengthForAnagram() {
		assertFalse(StringValidation.checkAnagram("sit", "twist"));
	}
	
	
	@Test
	public void testNullValuesForAnagramInput() {
		assertFalse(StringValidation.checkAnagram("", "twist"));
	}
	
	
	@Test
	public void testCaseSensitivityforAnagram() {
		assertTrue(StringValidation.checkAnagram("Silent", "Listen"));
	}
	
	/*
	@Test
	public void testNullValuesForPalindromeInput() {
		assertFalse(StringValidation.checkPalindrome(null));
	}
	*/

}
