import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Scanner;

public class StringValidation {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);

		String[] inputString = new String[getInput(input)];

		input.nextLine();
		for (int i = 0; i < inputString.length; i++) {
			inputString[i] = input.nextLine();
		}

		// If 1 string is entered then check if valid english word and then check
		// palindrome
		if (inputString.length == 1 && inputString[0] != null) {
			if (checkValidEnglishWord(inputString[0])) {
				checkPalindrome(inputString[0]);
			}
		}

		/*
		 * If 2 strings are entered then check if valid english word and then check
		 * Anagram, if one of the words is not a valid word it will not proceed
		 */
		if (inputString.length == 2 && inputString[0] != null && inputString[1] != null) {
			if (checkValidEnglishWord(inputString[0]) && checkValidEnglishWord(inputString[1])) {
				checkAnagram(inputString[0], inputString[1]);
			}

		}

	}

	public static int getInput(Scanner in) {
		System.out.println("Please enter the number of strings you want to enter(1 or 2): ");
		int input = 0;
		input = in.nextInt();
		while (input < 0 || input > 2) {
			System.out.println("Please enter a number between 1 and 2");
			input = in.nextInt();

		}
		return input;
	}

	public static boolean checkValidEnglishWord(String word) {

		boolean isValidEnglishWord = false;
		String apiUrl = "https://api.dictionaryapi.dev/api/v2/entries/en/" + word;

		try {
			// Fetch external API
			@SuppressWarnings("deprecation")
			HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			// If the word is found then it should return 200 success status code
			if (conn.getResponseCode() == 200) {
				isValidEnglishWord = true;
				System.out.println(word + " is a valid english word");
			} else {
				isValidEnglishWord = false;
				System.out.println(word + " is not a valid english word");
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return isValidEnglishWord;
	}

	public static boolean checkPalindrome(String input) {
		boolean isAPalindrome = false;
		String reverse = "";
		for (int i = input.length() - 1; i >= 0; i--) {
			reverse = reverse + input.charAt(i);
		}
		if (input.equalsIgnoreCase(reverse)) {
			isAPalindrome = true;
			System.out.println(input + " is a Palindrome");
		} else {
			isAPalindrome = false;
			System.out.println(input + " is not a Palindrome");
		}
		return isAPalindrome;
	}

	public static boolean checkAnagram(String input1, String input2) {
		// Check the length of both strings
		// If length is not equal they are not anagrams
		boolean isAnagram = false;
		// To handle case sensitivity
		String str1 = input1.toLowerCase();
		String str2 = input2.toLowerCase();

		if (str1.length() != str2.length()) {
			System.out.println("The words are not anagrams");
			return false;

		}

		if (str1.length() == str2.length()) {

			// Convert to char array

			char[] charArray1 = str1.toCharArray();
			char[] charArray2 = str2.toCharArray();

			// sort them using arrays.sort
			Arrays.sort(charArray1);
			Arrays.sort(charArray2);
			// compare the char arrays
			isAnagram = Arrays.equals(charArray1, charArray2);
		}
		if (isAnagram) {
			System.out.println("The given words are Anagrams");
			return isAnagram;
		} else {
			System.out.println("The given words are not Anagrams");
			return isAnagram;
		}

	}

}
